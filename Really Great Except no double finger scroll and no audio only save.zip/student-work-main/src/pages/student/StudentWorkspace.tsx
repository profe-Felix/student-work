// src/pages/student/StudentWorkspace.tsx
// This keeps your existing student page code intact while giving it a nicer URL/name.
import Assignment from './assignment';
export default Assignment;
